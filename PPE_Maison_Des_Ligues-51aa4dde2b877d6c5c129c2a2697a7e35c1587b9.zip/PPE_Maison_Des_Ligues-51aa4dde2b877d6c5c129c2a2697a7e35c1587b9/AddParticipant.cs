﻿using System.Data.SqlClient;
using System.Xml.Linq;

namespace PPE_Maison_Des_Ligues
{
    public class AddParticipant
    {
        
    }
}